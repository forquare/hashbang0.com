=== Plugin Name ===
Contributors: christopherross
Plugin URI: http://regentware.com/software/web-based/wordpress-plugins/no-more-frames
Tags: frames,seo,no frames, busting,spam,plugin,page,protection,admin,links
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=5732121
Requires at least: 2.0.0
Tested up to: 3.0.0
Stable tag: 1.5.0

Many web sites try to load your content into their own frame, to help sell ads on their sites. This plugin reloads sites such as Google images, forcing your website to load outside the frame.

== Description ==

Many web sites try to load your content into their own frame, to help sell ads on their sites. This simple plugin ensure your site is protect from this using a simple piece of code in your document header.

The plugin also dramatically reduces comment SPAM by making it significantly more frustrating for the page to be loaded into a secondary browser window.

== Installation ==

To install the plugin, please upload the folder to your plugins folder and active the plugin.

== Updates ==
Updates to the plugin will be posted here, to [thisismyurl](http://www.thisismyurl.com/plugins/no-more-frames)

== Donations ==
If you would like to donate to help support future development of this tool, please visit [https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=5732121)

== Frequently Asked Questions ==

Empty

== Change Log ==

0.5.2 (2009-03-16)
Added the change log

0.5.3 (2009-03-26)
- Happy Birthday to me
- Fixed a link in the readme.txt file

1.0.0 (2009-05-07)
- documentation updates
- official release

1.0.1
- added admin menus
- cleaned up files

1.1.0
- admin menu fixes for WordPress 2.8.0

1.1.4
- compatibility updates

1.1.6
- tested with 3.0.0

== Upgrade Notice ==

1.1.6
- tested with 3.0.0

== Screenshots ==